<?php
require_once(getabspath("classes/cipherer.php"));




$tdataPaciente = array();	
	$tdataPaciente[".truncateText"] = true;
	$tdataPaciente[".NumberOfChars"] = 80; 
	$tdataPaciente[".ShortName"] = "Paciente";
	$tdataPaciente[".OwnerID"] = "";
	$tdataPaciente[".OriginalTable"] = "Paciente";

//	field labels
$fieldLabelsPaciente = array();
$fieldToolTipsPaciente = array();
$pageTitlesPaciente = array();

if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsPaciente["Spanish"] = array();
	$fieldToolTipsPaciente["Spanish"] = array();
	$pageTitlesPaciente["Spanish"] = array();
	$fieldLabelsPaciente["Spanish"]["Id"] = "Id";
	$fieldToolTipsPaciente["Spanish"]["Id"] = "";
	$fieldLabelsPaciente["Spanish"]["TipoDocumento"] = "Tipo Documento";
	$fieldToolTipsPaciente["Spanish"]["TipoDocumento"] = "";
	$fieldLabelsPaciente["Spanish"]["Numero"] = "Numero";
	$fieldToolTipsPaciente["Spanish"]["Numero"] = "";
	$fieldLabelsPaciente["Spanish"]["Nombre"] = "Nombre";
	$fieldToolTipsPaciente["Spanish"]["Nombre"] = "";
	$fieldLabelsPaciente["Spanish"]["Apellido1"] = "Apellido1";
	$fieldToolTipsPaciente["Spanish"]["Apellido1"] = "";
	$fieldLabelsPaciente["Spanish"]["Apellido2"] = "Apellido2";
	$fieldToolTipsPaciente["Spanish"]["Apellido2"] = "";
	$fieldLabelsPaciente["Spanish"]["Email"] = "Email";
	$fieldToolTipsPaciente["Spanish"]["Email"] = "";
	$fieldLabelsPaciente["Spanish"]["Celular"] = "Celular";
	$fieldToolTipsPaciente["Spanish"]["Celular"] = "";
	$fieldLabelsPaciente["Spanish"]["Telefono"] = "Telefono";
	$fieldToolTipsPaciente["Spanish"]["Telefono"] = "";
	$fieldLabelsPaciente["Spanish"]["Direccion"] = "Direccion";
	$fieldToolTipsPaciente["Spanish"]["Direccion"] = "";
	$fieldLabelsPaciente["Spanish"]["Municipio"] = "Municipio";
	$fieldToolTipsPaciente["Spanish"]["Municipio"] = "";
	if (count($fieldToolTipsPaciente["Spanish"]))
		$tdataPaciente[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsPaciente[""] = array();
	$fieldToolTipsPaciente[""] = array();
	$pageTitlesPaciente[""] = array();
	$fieldLabelsPaciente[""]["Id"] = "Id";
	$fieldToolTipsPaciente[""]["Id"] = "";
	if (count($fieldToolTipsPaciente[""]))
		$tdataPaciente[".isUseToolTips"] = true;
}
	
	
	$tdataPaciente[".NCSearch"] = true;



$tdataPaciente[".shortTableName"] = "Paciente";
$tdataPaciente[".nSecOptions"] = 0;
$tdataPaciente[".recsPerRowList"] = 1;
$tdataPaciente[".mainTableOwnerID"] = "";
$tdataPaciente[".moveNext"] = 1;
$tdataPaciente[".nType"] = 0;

$tdataPaciente[".strOriginalTableName"] = "Paciente";




$tdataPaciente[".showAddInPopup"] = false;

$tdataPaciente[".showEditInPopup"] = false;

$tdataPaciente[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataPaciente[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataPaciente[".fieldsForRegister"] = array();

$tdataPaciente[".listAjax"] = false;

	$tdataPaciente[".audit"] = false;

	$tdataPaciente[".locking"] = false;

$tdataPaciente[".edit"] = true;

$tdataPaciente[".list"] = true;

$tdataPaciente[".inlineEdit"] = true;
$tdataPaciente[".inlineAdd"] = true;
$tdataPaciente[".view"] = true;

$tdataPaciente[".import"] = true;

$tdataPaciente[".exportTo"] = true;

$tdataPaciente[".printFriendly"] = true;

$tdataPaciente[".delete"] = true;

$tdataPaciente[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataPaciente[".searchSaving"] = false;
//

$tdataPaciente[".showSearchPanel"] = true;
		$tdataPaciente[".flexibleSearch"] = true;		

if (isMobile())
	$tdataPaciente[".isUseAjaxSuggest"] = false;
else 
	$tdataPaciente[".isUseAjaxSuggest"] = true;

$tdataPaciente[".rowHighlite"] = true;



$tdataPaciente[".addPageEvents"] = false;

// use timepicker for search panel
$tdataPaciente[".isUseTimeForSearch"] = false;



$tdataPaciente[".useDetailsPreview"] = true;


$tdataPaciente[".allSearchFields"] = array();
$tdataPaciente[".filterFields"] = array();
$tdataPaciente[".requiredSearchFields"] = array();

$tdataPaciente[".allSearchFields"][] = "Id";
	$tdataPaciente[".allSearchFields"][] = "TipoDocumento";
	$tdataPaciente[".allSearchFields"][] = "Numero";
	$tdataPaciente[".allSearchFields"][] = "Nombre";
	$tdataPaciente[".allSearchFields"][] = "Apellido1";
	$tdataPaciente[".allSearchFields"][] = "Apellido2";
	$tdataPaciente[".allSearchFields"][] = "Email";
	$tdataPaciente[".allSearchFields"][] = "Celular";
	$tdataPaciente[".allSearchFields"][] = "Telefono";
	$tdataPaciente[".allSearchFields"][] = "Direccion";
	$tdataPaciente[".allSearchFields"][] = "Municipio";
	

$tdataPaciente[".googleLikeFields"] = array();
$tdataPaciente[".googleLikeFields"][] = "Id";
$tdataPaciente[".googleLikeFields"][] = "TipoDocumento";
$tdataPaciente[".googleLikeFields"][] = "Numero";
$tdataPaciente[".googleLikeFields"][] = "Nombre";
$tdataPaciente[".googleLikeFields"][] = "Apellido1";
$tdataPaciente[".googleLikeFields"][] = "Apellido2";
$tdataPaciente[".googleLikeFields"][] = "Email";
$tdataPaciente[".googleLikeFields"][] = "Celular";
$tdataPaciente[".googleLikeFields"][] = "Telefono";
$tdataPaciente[".googleLikeFields"][] = "Direccion";
$tdataPaciente[".googleLikeFields"][] = "Municipio";


$tdataPaciente[".advSearchFields"] = array();
$tdataPaciente[".advSearchFields"][] = "Id";
$tdataPaciente[".advSearchFields"][] = "TipoDocumento";
$tdataPaciente[".advSearchFields"][] = "Numero";
$tdataPaciente[".advSearchFields"][] = "Nombre";
$tdataPaciente[".advSearchFields"][] = "Apellido1";
$tdataPaciente[".advSearchFields"][] = "Apellido2";
$tdataPaciente[".advSearchFields"][] = "Email";
$tdataPaciente[".advSearchFields"][] = "Celular";
$tdataPaciente[".advSearchFields"][] = "Telefono";
$tdataPaciente[".advSearchFields"][] = "Direccion";
$tdataPaciente[".advSearchFields"][] = "Municipio";

$tdataPaciente[".tableType"] = "list";

$tdataPaciente[".printerPageOrientation"] = 0;
$tdataPaciente[".nPrinterPageScale"] = 100;

$tdataPaciente[".nPrinterSplitRecords"] = 40;

$tdataPaciente[".nPrinterPDFSplitRecords"] = 40;





	





// view page pdf

// print page pdf


$tdataPaciente[".pageSize"] = 20;

$tdataPaciente[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataPaciente[".strOrderBy"] = $tstrOrderBy;

$tdataPaciente[".orderindexes"] = array();

$tdataPaciente[".sqlHead"] = "SELECT Id,  	TipoDocumento,  	Numero,  	Nombre,  	Apellido1,  	Apellido2,  	Email,  	Celular,  	Telefono,  	Direccion,  	Municipio";
$tdataPaciente[".sqlFrom"] = "FROM Paciente";
$tdataPaciente[".sqlWhereExpr"] = "";
$tdataPaciente[".sqlTail"] = "";




//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataPaciente[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataPaciente[".arrGroupsPerPage"] = $arrGPP;

$tdataPaciente[".highlightSearchResults"] = true;

$tableKeysPaciente = array();
$tableKeysPaciente[] = "Id";
$tdataPaciente[".Keys"] = $tableKeysPaciente;

$tdataPaciente[".listFields"] = array();
$tdataPaciente[".listFields"][] = "Id";
$tdataPaciente[".listFields"][] = "TipoDocumento";
$tdataPaciente[".listFields"][] = "Numero";
$tdataPaciente[".listFields"][] = "Nombre";
$tdataPaciente[".listFields"][] = "Apellido1";
$tdataPaciente[".listFields"][] = "Apellido2";
$tdataPaciente[".listFields"][] = "Email";
$tdataPaciente[".listFields"][] = "Celular";
$tdataPaciente[".listFields"][] = "Telefono";
$tdataPaciente[".listFields"][] = "Direccion";
$tdataPaciente[".listFields"][] = "Municipio";

$tdataPaciente[".hideMobileList"] = array();


$tdataPaciente[".viewFields"] = array();
$tdataPaciente[".viewFields"][] = "Id";
$tdataPaciente[".viewFields"][] = "TipoDocumento";
$tdataPaciente[".viewFields"][] = "Numero";
$tdataPaciente[".viewFields"][] = "Nombre";
$tdataPaciente[".viewFields"][] = "Apellido1";
$tdataPaciente[".viewFields"][] = "Apellido2";
$tdataPaciente[".viewFields"][] = "Email";
$tdataPaciente[".viewFields"][] = "Celular";
$tdataPaciente[".viewFields"][] = "Telefono";
$tdataPaciente[".viewFields"][] = "Direccion";
$tdataPaciente[".viewFields"][] = "Municipio";

$tdataPaciente[".addFields"] = array();
$tdataPaciente[".addFields"][] = "TipoDocumento";
$tdataPaciente[".addFields"][] = "Numero";
$tdataPaciente[".addFields"][] = "Nombre";
$tdataPaciente[".addFields"][] = "Apellido1";
$tdataPaciente[".addFields"][] = "Apellido2";
$tdataPaciente[".addFields"][] = "Email";
$tdataPaciente[".addFields"][] = "Celular";
$tdataPaciente[".addFields"][] = "Telefono";
$tdataPaciente[".addFields"][] = "Direccion";
$tdataPaciente[".addFields"][] = "Municipio";

$tdataPaciente[".inlineAddFields"] = array();
$tdataPaciente[".inlineAddFields"][] = "TipoDocumento";
$tdataPaciente[".inlineAddFields"][] = "Numero";
$tdataPaciente[".inlineAddFields"][] = "Nombre";
$tdataPaciente[".inlineAddFields"][] = "Apellido1";
$tdataPaciente[".inlineAddFields"][] = "Apellido2";
$tdataPaciente[".inlineAddFields"][] = "Email";
$tdataPaciente[".inlineAddFields"][] = "Celular";
$tdataPaciente[".inlineAddFields"][] = "Telefono";
$tdataPaciente[".inlineAddFields"][] = "Direccion";
$tdataPaciente[".inlineAddFields"][] = "Municipio";

$tdataPaciente[".editFields"] = array();
$tdataPaciente[".editFields"][] = "TipoDocumento";
$tdataPaciente[".editFields"][] = "Numero";
$tdataPaciente[".editFields"][] = "Nombre";
$tdataPaciente[".editFields"][] = "Apellido1";
$tdataPaciente[".editFields"][] = "Apellido2";
$tdataPaciente[".editFields"][] = "Email";
$tdataPaciente[".editFields"][] = "Celular";
$tdataPaciente[".editFields"][] = "Telefono";
$tdataPaciente[".editFields"][] = "Direccion";
$tdataPaciente[".editFields"][] = "Municipio";

$tdataPaciente[".inlineEditFields"] = array();
$tdataPaciente[".inlineEditFields"][] = "TipoDocumento";
$tdataPaciente[".inlineEditFields"][] = "Numero";
$tdataPaciente[".inlineEditFields"][] = "Nombre";
$tdataPaciente[".inlineEditFields"][] = "Apellido1";
$tdataPaciente[".inlineEditFields"][] = "Apellido2";
$tdataPaciente[".inlineEditFields"][] = "Email";
$tdataPaciente[".inlineEditFields"][] = "Celular";
$tdataPaciente[".inlineEditFields"][] = "Telefono";
$tdataPaciente[".inlineEditFields"][] = "Direccion";
$tdataPaciente[".inlineEditFields"][] = "Municipio";

$tdataPaciente[".exportFields"] = array();
$tdataPaciente[".exportFields"][] = "Id";
$tdataPaciente[".exportFields"][] = "TipoDocumento";
$tdataPaciente[".exportFields"][] = "Numero";
$tdataPaciente[".exportFields"][] = "Nombre";
$tdataPaciente[".exportFields"][] = "Apellido1";
$tdataPaciente[".exportFields"][] = "Apellido2";
$tdataPaciente[".exportFields"][] = "Email";
$tdataPaciente[".exportFields"][] = "Celular";
$tdataPaciente[".exportFields"][] = "Telefono";
$tdataPaciente[".exportFields"][] = "Direccion";
$tdataPaciente[".exportFields"][] = "Municipio";

$tdataPaciente[".importFields"] = array();
$tdataPaciente[".importFields"][] = "Id";
$tdataPaciente[".importFields"][] = "TipoDocumento";
$tdataPaciente[".importFields"][] = "Numero";
$tdataPaciente[".importFields"][] = "Nombre";
$tdataPaciente[".importFields"][] = "Apellido1";
$tdataPaciente[".importFields"][] = "Apellido2";
$tdataPaciente[".importFields"][] = "Email";
$tdataPaciente[".importFields"][] = "Celular";
$tdataPaciente[".importFields"][] = "Telefono";
$tdataPaciente[".importFields"][] = "Direccion";
$tdataPaciente[".importFields"][] = "Municipio";

$tdataPaciente[".printFields"] = array();
$tdataPaciente[".printFields"][] = "Id";
$tdataPaciente[".printFields"][] = "TipoDocumento";
$tdataPaciente[".printFields"][] = "Numero";
$tdataPaciente[".printFields"][] = "Nombre";
$tdataPaciente[".printFields"][] = "Apellido1";
$tdataPaciente[".printFields"][] = "Apellido2";
$tdataPaciente[".printFields"][] = "Email";
$tdataPaciente[".printFields"][] = "Celular";
$tdataPaciente[".printFields"][] = "Telefono";
$tdataPaciente[".printFields"][] = "Direccion";
$tdataPaciente[".printFields"][] = "Municipio";

//	Id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "Id";
	$fdata["GoodName"] = "Id";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Id"); 
	$fdata["FieldType"] = 3;
	
		
		$fdata["AutoInc"] = true;
	
		
				
		$fdata["bListPage"] = true; 
	
		
		
		
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Id"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Id";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		$edata["IsRequired"] = true; 
	
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
			
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");
// the end of search options settings	

	

	
	$tdataPaciente["Id"] = $fdata;
//	TipoDocumento
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "TipoDocumento";
	$fdata["GoodName"] = "TipoDocumento";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","TipoDocumento"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "TipoDocumento"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "TipoDocumento";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["TipoDocumento"] = $fdata;
//	Numero
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Numero";
	$fdata["GoodName"] = "Numero";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Numero"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Numero"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Numero";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["Numero"] = $fdata;
//	Nombre
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Nombre";
	$fdata["GoodName"] = "Nombre";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Nombre"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Nombre"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Nombre";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["Nombre"] = $fdata;
//	Apellido1
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "Apellido1";
	$fdata["GoodName"] = "Apellido1";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Apellido1"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Apellido1"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Apellido1";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["Apellido1"] = $fdata;
//	Apellido2
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "Apellido2";
	$fdata["GoodName"] = "Apellido2";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Apellido2"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Apellido2"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Apellido2";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["Apellido2"] = $fdata;
//	Email
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "Email";
	$fdata["GoodName"] = "Email";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Email"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Email"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Email";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "email";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=120";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["Email"] = $fdata;
//	Celular
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "Celular";
	$fdata["GoodName"] = "Celular";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Celular"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Celular"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Celular";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["Celular"] = $fdata;
//	Telefono
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "Telefono";
	$fdata["GoodName"] = "Telefono";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Telefono"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Telefono"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Telefono";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["Telefono"] = $fdata;
//	Direccion
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 10;
	$fdata["strName"] = "Direccion";
	$fdata["GoodName"] = "Direccion";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Direccion"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Direccion"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Direccion";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=120";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["Direccion"] = $fdata;
//	Municipio
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 11;
	$fdata["strName"] = "Municipio";
	$fdata["GoodName"] = "Municipio";
	$fdata["ownerTable"] = "Paciente";
	$fdata["Label"] = GetFieldLabel("Paciente","Municipio"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Municipio"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Municipio";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataPaciente["Municipio"] = $fdata;

	
$tables_data["Paciente"]=&$tdataPaciente;
$field_labels["Paciente"] = &$fieldLabelsPaciente;
$fieldToolTips["Paciente"] = &$fieldToolTipsPaciente;
$page_titles["Paciente"] = &$pageTitlesPaciente;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["Paciente"] = array();
//	Anamnesis
	
	

		$dIndex = 0;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="Anamnesis";
		$detailsParam["dOriginalTable"] = "Anamnesis";
				$detailsParam["dType"]=PAGE_LIST;
	$detailsParam["dShortTable"] = "Anamnesis";
	$detailsParam["dCaptionTable"] = GetTableCaption("Anamnesis");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();
	$detailsParam["dispChildCount"] = "1";
		$detailsParam["hideChild"] = false;
	$detailsParam["previewOnList"] = 1;
	$detailsParam["previewOnAdd"] = 0;
	$detailsParam["previewOnEdit"] = 0;
	$detailsParam["previewOnView"] = 0;
			
	$detailsTablesData["Paciente"][$dIndex] = $detailsParam;
	
		
		$detailsTablesData["Paciente"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["Paciente"][$dIndex]["masterKeys"][]="Id";

	$detailsTablesData["Paciente"][$dIndex]["masterKeys"][]="TipoDocumento";

	$detailsTablesData["Paciente"][$dIndex]["masterKeys"][]="Numero";

				$detailsTablesData["Paciente"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["Paciente"][$dIndex]["detailKeys"][]="IdA";

		
	$detailsTablesData["Paciente"][$dIndex]["detailKeys"][]="TipoDocumento";

		
	$detailsTablesData["Paciente"][$dIndex]["detailKeys"][]="Numero";
	
// tables which are master tables for current table (detail)
$masterTablesData["Paciente"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_Paciente()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "Id,  	TipoDocumento,  	Numero,  	Nombre,  	Apellido1,  	Apellido2,  	Email,  	Celular,  	Telefono,  	Direccion,  	Municipio";
$proto0["m_strFrom"] = "FROM Paciente";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
			$proto0["cipherer"] = null;
$proto1=array();
$proto1["m_sql"] = "";
$proto1["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto1["m_column"]=$obj;
$proto1["m_contained"] = array();
$proto1["m_strCase"] = "";
$proto1["m_havingmode"] = false;
$proto1["m_inBrackets"] = false;
$proto1["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto1);

$proto0["m_where"] = $obj;
$proto3=array();
$proto3["m_sql"] = "";
$proto3["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto3["m_column"]=$obj;
$proto3["m_contained"] = array();
$proto3["m_strCase"] = "";
$proto3["m_havingmode"] = false;
$proto3["m_inBrackets"] = false;
$proto3["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto3);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto5=array();
			$obj = new SQLField(array(
	"m_strName" => "Id",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto5["m_sql"] = "Id";
$proto5["m_srcTableName"] = "Paciente";
$proto5["m_expr"]=$obj;
$proto5["m_alias"] = "";
$obj = new SQLFieldListItem($proto5);

$proto0["m_fieldlist"][]=$obj;
						$proto7=array();
			$obj = new SQLField(array(
	"m_strName" => "TipoDocumento",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto7["m_sql"] = "TipoDocumento";
$proto7["m_srcTableName"] = "Paciente";
$proto7["m_expr"]=$obj;
$proto7["m_alias"] = "";
$obj = new SQLFieldListItem($proto7);

$proto0["m_fieldlist"][]=$obj;
						$proto9=array();
			$obj = new SQLField(array(
	"m_strName" => "Numero",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto9["m_sql"] = "Numero";
$proto9["m_srcTableName"] = "Paciente";
$proto9["m_expr"]=$obj;
$proto9["m_alias"] = "";
$obj = new SQLFieldListItem($proto9);

$proto0["m_fieldlist"][]=$obj;
						$proto11=array();
			$obj = new SQLField(array(
	"m_strName" => "Nombre",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto11["m_sql"] = "Nombre";
$proto11["m_srcTableName"] = "Paciente";
$proto11["m_expr"]=$obj;
$proto11["m_alias"] = "";
$obj = new SQLFieldListItem($proto11);

$proto0["m_fieldlist"][]=$obj;
						$proto13=array();
			$obj = new SQLField(array(
	"m_strName" => "Apellido1",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto13["m_sql"] = "Apellido1";
$proto13["m_srcTableName"] = "Paciente";
$proto13["m_expr"]=$obj;
$proto13["m_alias"] = "";
$obj = new SQLFieldListItem($proto13);

$proto0["m_fieldlist"][]=$obj;
						$proto15=array();
			$obj = new SQLField(array(
	"m_strName" => "Apellido2",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto15["m_sql"] = "Apellido2";
$proto15["m_srcTableName"] = "Paciente";
$proto15["m_expr"]=$obj;
$proto15["m_alias"] = "";
$obj = new SQLFieldListItem($proto15);

$proto0["m_fieldlist"][]=$obj;
						$proto17=array();
			$obj = new SQLField(array(
	"m_strName" => "Email",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto17["m_sql"] = "Email";
$proto17["m_srcTableName"] = "Paciente";
$proto17["m_expr"]=$obj;
$proto17["m_alias"] = "";
$obj = new SQLFieldListItem($proto17);

$proto0["m_fieldlist"][]=$obj;
						$proto19=array();
			$obj = new SQLField(array(
	"m_strName" => "Celular",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto19["m_sql"] = "Celular";
$proto19["m_srcTableName"] = "Paciente";
$proto19["m_expr"]=$obj;
$proto19["m_alias"] = "";
$obj = new SQLFieldListItem($proto19);

$proto0["m_fieldlist"][]=$obj;
						$proto21=array();
			$obj = new SQLField(array(
	"m_strName" => "Telefono",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto21["m_sql"] = "Telefono";
$proto21["m_srcTableName"] = "Paciente";
$proto21["m_expr"]=$obj;
$proto21["m_alias"] = "";
$obj = new SQLFieldListItem($proto21);

$proto0["m_fieldlist"][]=$obj;
						$proto23=array();
			$obj = new SQLField(array(
	"m_strName" => "Direccion",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto23["m_sql"] = "Direccion";
$proto23["m_srcTableName"] = "Paciente";
$proto23["m_expr"]=$obj;
$proto23["m_alias"] = "";
$obj = new SQLFieldListItem($proto23);

$proto0["m_fieldlist"][]=$obj;
						$proto25=array();
			$obj = new SQLField(array(
	"m_strName" => "Municipio",
	"m_strTable" => "Paciente",
	"m_srcTableName" => "Paciente"
));

$proto25["m_sql"] = "Municipio";
$proto25["m_srcTableName"] = "Paciente";
$proto25["m_expr"]=$obj;
$proto25["m_alias"] = "";
$obj = new SQLFieldListItem($proto25);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto27=array();
$proto27["m_link"] = "SQLL_MAIN";
			$proto28=array();
$proto28["m_strName"] = "Paciente";
$proto28["m_srcTableName"] = "Paciente";
$proto28["m_columns"] = array();
$proto28["m_columns"][] = "Id";
$proto28["m_columns"][] = "TipoDocumento";
$proto28["m_columns"][] = "Numero";
$proto28["m_columns"][] = "Nombre";
$proto28["m_columns"][] = "Apellido1";
$proto28["m_columns"][] = "Apellido2";
$proto28["m_columns"][] = "Email";
$proto28["m_columns"][] = "Celular";
$proto28["m_columns"][] = "Telefono";
$proto28["m_columns"][] = "Direccion";
$proto28["m_columns"][] = "Municipio";
$obj = new SQLTable($proto28);

$proto27["m_table"] = $obj;
$proto27["m_sql"] = "Paciente";
$proto27["m_alias"] = "";
$proto27["m_srcTableName"] = "Paciente";
$proto29=array();
$proto29["m_sql"] = "";
$proto29["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto29["m_column"]=$obj;
$proto29["m_contained"] = array();
$proto29["m_strCase"] = "";
$proto29["m_havingmode"] = false;
$proto29["m_inBrackets"] = false;
$proto29["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto29);

$proto27["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto27);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="Paciente";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_Paciente = createSqlQuery_Paciente();


	
											
	
$tdataPaciente[".sqlquery"] = $queryData_Paciente;

$tableEvents["Paciente"] = new eventsBase;
$tdataPaciente[".hasEvents"] = false;

?>