<?php
function DisplayMasterTableInfoForPrint_Paciente($params)
{
	global $cman;
	
	$detailtable = $params["detailtable"];
	$keys = $params["keys"];
	
	$xt = new Xtempl();
	
	$tName = "Paciente";
	$xt->eventsObject = getEventObject($tName);

	$cipherer = new RunnerCipherer( $tName );
	$settings = new ProjectSettings($tName, PAGE_PRINT);
	$connection = $cman->byTable( $tName );
	
	$masterQuery = $settings->getSQLQuery();
	$viewControls = new ViewControlsContainer($settings, PAGE_PRINT);

	$where = "";
	$keysAssoc = array();
	$showKeys = "";

	if( $detailtable == "Anamnesis" )
	{
		$keysAssoc["Id"] = $keys[1-1];
		$keysAssoc["TipoDocumento"] = $keys[2-1];
		$keysAssoc["Numero"] = $keys[3-1];
				$where.= RunnerPage::_getFieldSQLDecrypt("Id", $connection , $settings , $cipherer) . "=" . $cipherer->MakeDBValue("Id", $keys[1-1], "", true);

				$keyValue = $viewControls->showDBValue("Id", $keysAssoc);
		$showKeys.= " ".GetFieldLabel("Paciente","Id").": ".$keyValue;
				$where.= " and ";
		$showKeys.= " , ";
		$where.= RunnerPage::_getFieldSQLDecrypt("TipoDocumento", $connection , $settings , $cipherer) . "=" . $cipherer->MakeDBValue("TipoDocumento", $keys[2-1], "", true);

				$keyValue = $viewControls->showDBValue("TipoDocumento", $keysAssoc);
		$showKeys.= " ".GetFieldLabel("Paciente","TipoDocumento").": ".$keyValue;
				$where.= " and ";
		$showKeys.= " , ";
		$where.= RunnerPage::_getFieldSQLDecrypt("Numero", $connection , $settings , $cipherer) . "=" . $cipherer->MakeDBValue("Numero", $keys[3-1], "", true);

				$keyValue = $viewControls->showDBValue("Numero", $keysAssoc);
		$showKeys.= " ".GetFieldLabel("Paciente","Numero").": ".$keyValue;
		$xt->assign('showKeys', $showKeys);	
	}

	if( !$where )
		return;

	$str = SecuritySQL("Export", $tName );
	if( strlen($str) )
		$where.= " and ".$str;
	
	$strWhere = whereAdd( $masterQuery->m_where->toSql($masterQuery), $where );
	if( strlen($strWhere) )
		$strWhere= " where ".$strWhere." ";
		
	$strSQL = $masterQuery->HeadToSql().' '.$masterQuery->FromToSql().$strWhere.$masterQuery->TailToSql();
	LogInfo($strSQL);
	
	$data = $cipherer->DecryptFetchedArray( $connection->query( $strSQL )->fetchAssoc() );
	if( !$data )
		return;
	
	// reassign pagetitlelabel function adding extra params
	$xt->assign_function("pagetitlelabel", "xt_pagetitlelabel", array("record" => $data, "settings" => $settings));	
	
	$keylink = "";
	$keylink.= "&key1=".runner_htmlspecialchars(rawurlencode(@$data["Id"]));
	
	$xt->assign("Id_mastervalue", $viewControls->showDBValue("Id", $data, $keylink));
	$format = $settings->getViewFormat("Id");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Id")))
		$class = ' rnr-field-number';
		
	$xt->assign("Id_class", $class); // add class for field header as field value
	$xt->assign("TipoDocumento_mastervalue", $viewControls->showDBValue("TipoDocumento", $data, $keylink));
	$format = $settings->getViewFormat("TipoDocumento");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("TipoDocumento")))
		$class = ' rnr-field-number';
		
	$xt->assign("TipoDocumento_class", $class); // add class for field header as field value
	$xt->assign("Numero_mastervalue", $viewControls->showDBValue("Numero", $data, $keylink));
	$format = $settings->getViewFormat("Numero");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Numero")))
		$class = ' rnr-field-number';
		
	$xt->assign("Numero_class", $class); // add class for field header as field value
	$xt->assign("Nombre_mastervalue", $viewControls->showDBValue("Nombre", $data, $keylink));
	$format = $settings->getViewFormat("Nombre");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Nombre")))
		$class = ' rnr-field-number';
		
	$xt->assign("Nombre_class", $class); // add class for field header as field value
	$xt->assign("Apellido1_mastervalue", $viewControls->showDBValue("Apellido1", $data, $keylink));
	$format = $settings->getViewFormat("Apellido1");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Apellido1")))
		$class = ' rnr-field-number';
		
	$xt->assign("Apellido1_class", $class); // add class for field header as field value
	$xt->assign("Apellido2_mastervalue", $viewControls->showDBValue("Apellido2", $data, $keylink));
	$format = $settings->getViewFormat("Apellido2");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Apellido2")))
		$class = ' rnr-field-number';
		
	$xt->assign("Apellido2_class", $class); // add class for field header as field value
	$xt->assign("Email_mastervalue", $viewControls->showDBValue("Email", $data, $keylink));
	$format = $settings->getViewFormat("Email");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Email")))
		$class = ' rnr-field-number';
		
	$xt->assign("Email_class", $class); // add class for field header as field value
	$xt->assign("Celular_mastervalue", $viewControls->showDBValue("Celular", $data, $keylink));
	$format = $settings->getViewFormat("Celular");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Celular")))
		$class = ' rnr-field-number';
		
	$xt->assign("Celular_class", $class); // add class for field header as field value
	$xt->assign("Telefono_mastervalue", $viewControls->showDBValue("Telefono", $data, $keylink));
	$format = $settings->getViewFormat("Telefono");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Telefono")))
		$class = ' rnr-field-number';
		
	$xt->assign("Telefono_class", $class); // add class for field header as field value
	$xt->assign("Direccion_mastervalue", $viewControls->showDBValue("Direccion", $data, $keylink));
	$format = $settings->getViewFormat("Direccion");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Direccion")))
		$class = ' rnr-field-number';
		
	$xt->assign("Direccion_class", $class); // add class for field header as field value
	$xt->assign("Municipio_mastervalue", $viewControls->showDBValue("Municipio", $data, $keylink));
	$format = $settings->getViewFormat("Municipio");
	$class = " rnr-field-text";
	if($format == FORMAT_FILE) 
		$class = ' rnr-field-file'; 
	if($format == FORMAT_AUDIO)
		$class = ' rnr-field-audio';
	if($format == FORMAT_CHECKBOX)
		$class = ' rnr-field-checkbox';
	if($format == FORMAT_NUMBER || IsNumberType($settings->getFieldType("Municipio")))
		$class = ' rnr-field-number';
		
	$xt->assign("Municipio_class", $class); // add class for field header as field value

	$layout = GetPageLayout("Paciente", 'masterprint');
	if( $layout )
		$xt->assign("pageattrs", 'class="'.$layout->style." page-".$layout->name.'"');

	$xt->displayPartial(GetTemplateName("Paciente", "masterprint"));
}

?>