<?php
$dalTablePaciente = array();
$dalTablePaciente["Id"] = array("type"=>3,"varname"=>"Id");
$dalTablePaciente["TipoDocumento"] = array("type"=>202,"varname"=>"TipoDocumento");
$dalTablePaciente["Numero"] = array("type"=>202,"varname"=>"Numero");
$dalTablePaciente["Nombre"] = array("type"=>202,"varname"=>"Nombre");
$dalTablePaciente["Apellido1"] = array("type"=>202,"varname"=>"Apellido1");
$dalTablePaciente["Apellido2"] = array("type"=>202,"varname"=>"Apellido2");
$dalTablePaciente["Email"] = array("type"=>202,"varname"=>"Email");
$dalTablePaciente["Celular"] = array("type"=>202,"varname"=>"Celular");
$dalTablePaciente["Telefono"] = array("type"=>202,"varname"=>"Telefono");
$dalTablePaciente["Direccion"] = array("type"=>202,"varname"=>"Direccion");
$dalTablePaciente["Municipio"] = array("type"=>202,"varname"=>"Municipio");
	$dalTablePaciente["Id"]["key"]=true;

$dal_info["Project12_mdb__Paciente"] = &$dalTablePaciente;
?>