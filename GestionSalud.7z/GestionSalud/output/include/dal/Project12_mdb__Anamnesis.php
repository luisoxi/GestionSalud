<?php
$dalTableAnamnesis = array();
$dalTableAnamnesis["IdA"] = array("type"=>3,"varname"=>"IdA");
$dalTableAnamnesis["TipoDocumento"] = array("type"=>202,"varname"=>"TipoDocumento");
$dalTableAnamnesis["Numero"] = array("type"=>202,"varname"=>"Numero");
$dalTableAnamnesis["Fecha"] = array("type"=>7,"varname"=>"Fecha");
$dalTableAnamnesis["MotivoConsulta"] = array("type"=>203,"varname"=>"MotivoConsulta");
$dalTableAnamnesis["Anamnesis"] = array("type"=>203,"varname"=>"Anamnesis");
$dalTableAnamnesis["ExamenFisico"] = array("type"=>203,"varname"=>"ExamenFisico");
$dalTableAnamnesis["Diagnostico"] = array("type"=>203,"varname"=>"Diagnostico");
$dalTableAnamnesis["Tratamiento"] = array("type"=>203,"varname"=>"Tratamiento");
	$dalTableAnamnesis["IdA"]["key"]=true;

$dal_info["Project12_mdb__Anamnesis"] = &$dalTableAnamnesis;
?>