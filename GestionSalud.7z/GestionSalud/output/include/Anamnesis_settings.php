<?php
require_once(getabspath("classes/cipherer.php"));




$tdataAnamnesis = array();	
	$tdataAnamnesis[".truncateText"] = true;
	$tdataAnamnesis[".NumberOfChars"] = 80; 
	$tdataAnamnesis[".ShortName"] = "Anamnesis";
	$tdataAnamnesis[".OwnerID"] = "";
	$tdataAnamnesis[".OriginalTable"] = "Anamnesis";

//	field labels
$fieldLabelsAnamnesis = array();
$fieldToolTipsAnamnesis = array();
$pageTitlesAnamnesis = array();

if(mlang_getcurrentlang()=="Spanish")
{
	$fieldLabelsAnamnesis["Spanish"] = array();
	$fieldToolTipsAnamnesis["Spanish"] = array();
	$pageTitlesAnamnesis["Spanish"] = array();
	$fieldLabelsAnamnesis["Spanish"]["IdA"] = "Id A";
	$fieldToolTipsAnamnesis["Spanish"]["IdA"] = "";
	$fieldLabelsAnamnesis["Spanish"]["TipoDocumento"] = "Tipo Documento";
	$fieldToolTipsAnamnesis["Spanish"]["TipoDocumento"] = "";
	$fieldLabelsAnamnesis["Spanish"]["Numero"] = "Numero";
	$fieldToolTipsAnamnesis["Spanish"]["Numero"] = "";
	$fieldLabelsAnamnesis["Spanish"]["Fecha"] = "Fecha";
	$fieldToolTipsAnamnesis["Spanish"]["Fecha"] = "";
	$fieldLabelsAnamnesis["Spanish"]["MotivoConsulta"] = "Motivo Consulta";
	$fieldToolTipsAnamnesis["Spanish"]["MotivoConsulta"] = "";
	$fieldLabelsAnamnesis["Spanish"]["Anamnesis"] = "Anamnesis";
	$fieldToolTipsAnamnesis["Spanish"]["Anamnesis"] = "";
	$fieldLabelsAnamnesis["Spanish"]["ExamenFisico"] = "Examen Fisico";
	$fieldToolTipsAnamnesis["Spanish"]["ExamenFisico"] = "";
	$fieldLabelsAnamnesis["Spanish"]["Diagnostico"] = "Diagnostico";
	$fieldToolTipsAnamnesis["Spanish"]["Diagnostico"] = "";
	$fieldLabelsAnamnesis["Spanish"]["Tratamiento"] = "Tratamiento";
	$fieldToolTipsAnamnesis["Spanish"]["Tratamiento"] = "";
	if (count($fieldToolTipsAnamnesis["Spanish"]))
		$tdataAnamnesis[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsAnamnesis[""] = array();
	$fieldToolTipsAnamnesis[""] = array();
	$pageTitlesAnamnesis[""] = array();
	$fieldLabelsAnamnesis[""]["IdA"] = "Id A";
	$fieldToolTipsAnamnesis[""]["IdA"] = "";
	if (count($fieldToolTipsAnamnesis[""]))
		$tdataAnamnesis[".isUseToolTips"] = true;
}
	
	
	$tdataAnamnesis[".NCSearch"] = true;



$tdataAnamnesis[".shortTableName"] = "Anamnesis";
$tdataAnamnesis[".nSecOptions"] = 0;
$tdataAnamnesis[".recsPerRowList"] = 1;
$tdataAnamnesis[".mainTableOwnerID"] = "";
$tdataAnamnesis[".moveNext"] = 1;
$tdataAnamnesis[".nType"] = 0;

$tdataAnamnesis[".strOriginalTableName"] = "Anamnesis";




$tdataAnamnesis[".showAddInPopup"] = false;

$tdataAnamnesis[".showEditInPopup"] = false;

$tdataAnamnesis[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataAnamnesis[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataAnamnesis[".fieldsForRegister"] = array();

$tdataAnamnesis[".listAjax"] = false;

	$tdataAnamnesis[".audit"] = false;

	$tdataAnamnesis[".locking"] = false;

$tdataAnamnesis[".edit"] = true;

$tdataAnamnesis[".list"] = true;

$tdataAnamnesis[".inlineEdit"] = true;
$tdataAnamnesis[".inlineAdd"] = true;
$tdataAnamnesis[".view"] = true;

$tdataAnamnesis[".import"] = true;

$tdataAnamnesis[".exportTo"] = true;

$tdataAnamnesis[".printFriendly"] = true;

$tdataAnamnesis[".delete"] = true;

$tdataAnamnesis[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataAnamnesis[".searchSaving"] = false;
//

$tdataAnamnesis[".showSearchPanel"] = true;
		$tdataAnamnesis[".flexibleSearch"] = true;		

if (isMobile())
	$tdataAnamnesis[".isUseAjaxSuggest"] = false;
else 
	$tdataAnamnesis[".isUseAjaxSuggest"] = true;

$tdataAnamnesis[".rowHighlite"] = true;



$tdataAnamnesis[".addPageEvents"] = false;

// use timepicker for search panel
$tdataAnamnesis[".isUseTimeForSearch"] = false;





$tdataAnamnesis[".allSearchFields"] = array();
$tdataAnamnesis[".filterFields"] = array();
$tdataAnamnesis[".requiredSearchFields"] = array();

$tdataAnamnesis[".allSearchFields"][] = "IdA";
	$tdataAnamnesis[".allSearchFields"][] = "TipoDocumento";
	$tdataAnamnesis[".allSearchFields"][] = "Numero";
	$tdataAnamnesis[".allSearchFields"][] = "Fecha";
	$tdataAnamnesis[".allSearchFields"][] = "MotivoConsulta";
	$tdataAnamnesis[".allSearchFields"][] = "Anamnesis";
	$tdataAnamnesis[".allSearchFields"][] = "ExamenFisico";
	$tdataAnamnesis[".allSearchFields"][] = "Diagnostico";
	$tdataAnamnesis[".allSearchFields"][] = "Tratamiento";
	

$tdataAnamnesis[".googleLikeFields"] = array();
$tdataAnamnesis[".googleLikeFields"][] = "IdA";
$tdataAnamnesis[".googleLikeFields"][] = "TipoDocumento";
$tdataAnamnesis[".googleLikeFields"][] = "Numero";
$tdataAnamnesis[".googleLikeFields"][] = "Fecha";
$tdataAnamnesis[".googleLikeFields"][] = "MotivoConsulta";
$tdataAnamnesis[".googleLikeFields"][] = "Anamnesis";
$tdataAnamnesis[".googleLikeFields"][] = "ExamenFisico";
$tdataAnamnesis[".googleLikeFields"][] = "Diagnostico";
$tdataAnamnesis[".googleLikeFields"][] = "Tratamiento";


$tdataAnamnesis[".advSearchFields"] = array();
$tdataAnamnesis[".advSearchFields"][] = "IdA";
$tdataAnamnesis[".advSearchFields"][] = "TipoDocumento";
$tdataAnamnesis[".advSearchFields"][] = "Numero";
$tdataAnamnesis[".advSearchFields"][] = "Fecha";
$tdataAnamnesis[".advSearchFields"][] = "MotivoConsulta";
$tdataAnamnesis[".advSearchFields"][] = "Anamnesis";
$tdataAnamnesis[".advSearchFields"][] = "ExamenFisico";
$tdataAnamnesis[".advSearchFields"][] = "Diagnostico";
$tdataAnamnesis[".advSearchFields"][] = "Tratamiento";

$tdataAnamnesis[".tableType"] = "list";

$tdataAnamnesis[".printerPageOrientation"] = 0;
$tdataAnamnesis[".nPrinterPageScale"] = 100;

$tdataAnamnesis[".nPrinterSplitRecords"] = 40;

$tdataAnamnesis[".nPrinterPDFSplitRecords"] = 40;





	





// view page pdf

// print page pdf


$tdataAnamnesis[".pageSize"] = 20;

$tdataAnamnesis[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataAnamnesis[".strOrderBy"] = $tstrOrderBy;

$tdataAnamnesis[".orderindexes"] = array();

$tdataAnamnesis[".sqlHead"] = "SELECT IdA,  	TipoDocumento,  	Numero,  	Fecha,  	MotivoConsulta,  	Anamnesis,  	ExamenFisico,  	Diagnostico,  	Tratamiento";
$tdataAnamnesis[".sqlFrom"] = "FROM Anamnesis";
$tdataAnamnesis[".sqlWhereExpr"] = "";
$tdataAnamnesis[".sqlTail"] = "";




//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataAnamnesis[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataAnamnesis[".arrGroupsPerPage"] = $arrGPP;

$tdataAnamnesis[".highlightSearchResults"] = true;

$tableKeysAnamnesis = array();
$tableKeysAnamnesis[] = "IdA";
$tdataAnamnesis[".Keys"] = $tableKeysAnamnesis;

$tdataAnamnesis[".listFields"] = array();
$tdataAnamnesis[".listFields"][] = "IdA";
$tdataAnamnesis[".listFields"][] = "TipoDocumento";
$tdataAnamnesis[".listFields"][] = "Numero";
$tdataAnamnesis[".listFields"][] = "Fecha";
$tdataAnamnesis[".listFields"][] = "MotivoConsulta";
$tdataAnamnesis[".listFields"][] = "Anamnesis";
$tdataAnamnesis[".listFields"][] = "ExamenFisico";
$tdataAnamnesis[".listFields"][] = "Diagnostico";
$tdataAnamnesis[".listFields"][] = "Tratamiento";

$tdataAnamnesis[".hideMobileList"] = array();


$tdataAnamnesis[".viewFields"] = array();
$tdataAnamnesis[".viewFields"][] = "IdA";
$tdataAnamnesis[".viewFields"][] = "TipoDocumento";
$tdataAnamnesis[".viewFields"][] = "Numero";
$tdataAnamnesis[".viewFields"][] = "Fecha";
$tdataAnamnesis[".viewFields"][] = "MotivoConsulta";
$tdataAnamnesis[".viewFields"][] = "Anamnesis";
$tdataAnamnesis[".viewFields"][] = "ExamenFisico";
$tdataAnamnesis[".viewFields"][] = "Diagnostico";
$tdataAnamnesis[".viewFields"][] = "Tratamiento";

$tdataAnamnesis[".addFields"] = array();
$tdataAnamnesis[".addFields"][] = "TipoDocumento";
$tdataAnamnesis[".addFields"][] = "Numero";
$tdataAnamnesis[".addFields"][] = "Fecha";
$tdataAnamnesis[".addFields"][] = "MotivoConsulta";
$tdataAnamnesis[".addFields"][] = "Anamnesis";
$tdataAnamnesis[".addFields"][] = "ExamenFisico";
$tdataAnamnesis[".addFields"][] = "Diagnostico";
$tdataAnamnesis[".addFields"][] = "Tratamiento";

$tdataAnamnesis[".inlineAddFields"] = array();
$tdataAnamnesis[".inlineAddFields"][] = "TipoDocumento";
$tdataAnamnesis[".inlineAddFields"][] = "Numero";
$tdataAnamnesis[".inlineAddFields"][] = "Fecha";
$tdataAnamnesis[".inlineAddFields"][] = "MotivoConsulta";
$tdataAnamnesis[".inlineAddFields"][] = "Anamnesis";
$tdataAnamnesis[".inlineAddFields"][] = "ExamenFisico";
$tdataAnamnesis[".inlineAddFields"][] = "Diagnostico";
$tdataAnamnesis[".inlineAddFields"][] = "Tratamiento";

$tdataAnamnesis[".editFields"] = array();
$tdataAnamnesis[".editFields"][] = "TipoDocumento";
$tdataAnamnesis[".editFields"][] = "Numero";
$tdataAnamnesis[".editFields"][] = "Fecha";
$tdataAnamnesis[".editFields"][] = "MotivoConsulta";
$tdataAnamnesis[".editFields"][] = "Anamnesis";
$tdataAnamnesis[".editFields"][] = "ExamenFisico";
$tdataAnamnesis[".editFields"][] = "Diagnostico";
$tdataAnamnesis[".editFields"][] = "Tratamiento";

$tdataAnamnesis[".inlineEditFields"] = array();
$tdataAnamnesis[".inlineEditFields"][] = "TipoDocumento";
$tdataAnamnesis[".inlineEditFields"][] = "Numero";
$tdataAnamnesis[".inlineEditFields"][] = "Fecha";
$tdataAnamnesis[".inlineEditFields"][] = "MotivoConsulta";
$tdataAnamnesis[".inlineEditFields"][] = "Anamnesis";
$tdataAnamnesis[".inlineEditFields"][] = "ExamenFisico";
$tdataAnamnesis[".inlineEditFields"][] = "Diagnostico";
$tdataAnamnesis[".inlineEditFields"][] = "Tratamiento";

$tdataAnamnesis[".exportFields"] = array();
$tdataAnamnesis[".exportFields"][] = "IdA";
$tdataAnamnesis[".exportFields"][] = "TipoDocumento";
$tdataAnamnesis[".exportFields"][] = "Numero";
$tdataAnamnesis[".exportFields"][] = "Fecha";
$tdataAnamnesis[".exportFields"][] = "MotivoConsulta";
$tdataAnamnesis[".exportFields"][] = "Anamnesis";
$tdataAnamnesis[".exportFields"][] = "ExamenFisico";
$tdataAnamnesis[".exportFields"][] = "Diagnostico";
$tdataAnamnesis[".exportFields"][] = "Tratamiento";

$tdataAnamnesis[".importFields"] = array();
$tdataAnamnesis[".importFields"][] = "IdA";
$tdataAnamnesis[".importFields"][] = "TipoDocumento";
$tdataAnamnesis[".importFields"][] = "Numero";
$tdataAnamnesis[".importFields"][] = "Fecha";
$tdataAnamnesis[".importFields"][] = "MotivoConsulta";
$tdataAnamnesis[".importFields"][] = "Anamnesis";
$tdataAnamnesis[".importFields"][] = "ExamenFisico";
$tdataAnamnesis[".importFields"][] = "Diagnostico";
$tdataAnamnesis[".importFields"][] = "Tratamiento";

$tdataAnamnesis[".printFields"] = array();
$tdataAnamnesis[".printFields"][] = "IdA";
$tdataAnamnesis[".printFields"][] = "TipoDocumento";
$tdataAnamnesis[".printFields"][] = "Numero";
$tdataAnamnesis[".printFields"][] = "Fecha";
$tdataAnamnesis[".printFields"][] = "MotivoConsulta";
$tdataAnamnesis[".printFields"][] = "Anamnesis";
$tdataAnamnesis[".printFields"][] = "ExamenFisico";
$tdataAnamnesis[".printFields"][] = "Diagnostico";
$tdataAnamnesis[".printFields"][] = "Tratamiento";

//	IdA
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "IdA";
	$fdata["GoodName"] = "IdA";
	$fdata["ownerTable"] = "Anamnesis";
	$fdata["Label"] = GetFieldLabel("Anamnesis","IdA"); 
	$fdata["FieldType"] = 3;
	
		
		$fdata["AutoInc"] = true;
	
		
				
		$fdata["bListPage"] = true; 
	
		
		
		
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "IdA"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "IdA";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		$edata["IsRequired"] = true; 
	
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
			
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");
// the end of search options settings	

	

	
	$tdataAnamnesis["IdA"] = $fdata;
//	TipoDocumento
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "TipoDocumento";
	$fdata["GoodName"] = "TipoDocumento";
	$fdata["ownerTable"] = "Anamnesis";
	$fdata["Label"] = GetFieldLabel("Anamnesis","TipoDocumento"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "TipoDocumento"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "TipoDocumento";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataAnamnesis["TipoDocumento"] = $fdata;
//	Numero
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Numero";
	$fdata["GoodName"] = "Numero";
	$fdata["ownerTable"] = "Anamnesis";
	$fdata["Label"] = GetFieldLabel("Anamnesis","Numero"); 
	$fdata["FieldType"] = 202;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Numero"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Numero";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataAnamnesis["Numero"] = $fdata;
//	Fecha
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Fecha";
	$fdata["GoodName"] = "Fecha";
	$fdata["ownerTable"] = "Anamnesis";
	$fdata["Label"] = GetFieldLabel("Anamnesis","Fecha"); 
	$fdata["FieldType"] = 7;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Fecha"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Fecha";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "Short Date");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Date");
	
			
	
	


		$edata["IsRequired"] = true; 
	
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		$edata["DateEditType"] = 13; 
	$edata["InitialYearFactor"] = 100; 
	$edata["LastYearFactor"] = 10; 
	
		
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
			
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");
// the end of search options settings	

	

	
	$tdataAnamnesis["Fecha"] = $fdata;
//	MotivoConsulta
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "MotivoConsulta";
	$fdata["GoodName"] = "MotivoConsulta";
	$fdata["ownerTable"] = "Anamnesis";
	$fdata["Label"] = GetFieldLabel("Anamnesis","MotivoConsulta"); 
	$fdata["FieldType"] = 203;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "MotivoConsulta"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "MotivoConsulta";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text area");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;
	
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataAnamnesis["MotivoConsulta"] = $fdata;
//	Anamnesis
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "Anamnesis";
	$fdata["GoodName"] = "Anamnesis";
	$fdata["ownerTable"] = "Anamnesis";
	$fdata["Label"] = GetFieldLabel("Anamnesis","Anamnesis"); 
	$fdata["FieldType"] = 203;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Anamnesis"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Anamnesis";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text area");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;
	
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataAnamnesis["Anamnesis"] = $fdata;
//	ExamenFisico
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "ExamenFisico";
	$fdata["GoodName"] = "ExamenFisico";
	$fdata["ownerTable"] = "Anamnesis";
	$fdata["Label"] = GetFieldLabel("Anamnesis","ExamenFisico"); 
	$fdata["FieldType"] = 203;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "ExamenFisico"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ExamenFisico";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text area");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;
	
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataAnamnesis["ExamenFisico"] = $fdata;
//	Diagnostico
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "Diagnostico";
	$fdata["GoodName"] = "Diagnostico";
	$fdata["ownerTable"] = "Anamnesis";
	$fdata["Label"] = GetFieldLabel("Anamnesis","Diagnostico"); 
	$fdata["FieldType"] = 203;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Diagnostico"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Diagnostico";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text area");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;
	
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataAnamnesis["Diagnostico"] = $fdata;
//	Tratamiento
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "Tratamiento";
	$fdata["GoodName"] = "Tratamiento";
	$fdata["ownerTable"] = "Anamnesis";
	$fdata["Label"] = GetFieldLabel("Anamnesis","Tratamiento"); 
	$fdata["FieldType"] = 203;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "Tratamiento"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Tratamiento";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text area");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;
	
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataAnamnesis["Tratamiento"] = $fdata;

	
$tables_data["Anamnesis"]=&$tdataAnamnesis;
$field_labels["Anamnesis"] = &$fieldLabelsAnamnesis;
$fieldToolTips["Anamnesis"] = &$fieldToolTipsAnamnesis;
$page_titles["Anamnesis"] = &$pageTitlesAnamnesis;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["Anamnesis"] = array();
	
// tables which are master tables for current table (detail)
$masterTablesData["Anamnesis"] = array();


	
				$strOriginalDetailsTable="Paciente";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="Paciente";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "Paciente";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();
	$masterParams["dispChildCount"]= "1";
	$masterParams["hideChild"]= "0";
	$masterParams["dispInfo"]= "1";
	$masterParams["previewOnList"]= 1;
	$masterParams["previewOnAdd"]= 0;
	$masterParams["previewOnEdit"]= 0;
	$masterParams["previewOnView"]= 0;
	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["Anamnesis"][0] = $masterParams;	
				$masterTablesData["Anamnesis"][0]["masterKeys"] = array();
	$masterTablesData["Anamnesis"][0]["masterKeys"][]="Id";
				$masterTablesData["Anamnesis"][0]["masterKeys"][]="TipoDocumento";
				$masterTablesData["Anamnesis"][0]["masterKeys"][]="Numero";
				$masterTablesData["Anamnesis"][0]["detailKeys"] = array();
	$masterTablesData["Anamnesis"][0]["detailKeys"][]="IdA";
				$masterTablesData["Anamnesis"][0]["detailKeys"][]="TipoDocumento";
				$masterTablesData["Anamnesis"][0]["detailKeys"][]="Numero";
		
// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_Anamnesis()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "IdA,  	TipoDocumento,  	Numero,  	Fecha,  	MotivoConsulta,  	Anamnesis,  	ExamenFisico,  	Diagnostico,  	Tratamiento";
$proto0["m_strFrom"] = "FROM Anamnesis";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
			$proto0["cipherer"] = null;
$proto1=array();
$proto1["m_sql"] = "";
$proto1["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto1["m_column"]=$obj;
$proto1["m_contained"] = array();
$proto1["m_strCase"] = "";
$proto1["m_havingmode"] = false;
$proto1["m_inBrackets"] = false;
$proto1["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto1);

$proto0["m_where"] = $obj;
$proto3=array();
$proto3["m_sql"] = "";
$proto3["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto3["m_column"]=$obj;
$proto3["m_contained"] = array();
$proto3["m_strCase"] = "";
$proto3["m_havingmode"] = false;
$proto3["m_inBrackets"] = false;
$proto3["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto3);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto5=array();
			$obj = new SQLField(array(
	"m_strName" => "IdA",
	"m_strTable" => "Anamnesis",
	"m_srcTableName" => "Anamnesis"
));

$proto5["m_sql"] = "IdA";
$proto5["m_srcTableName"] = "Anamnesis";
$proto5["m_expr"]=$obj;
$proto5["m_alias"] = "";
$obj = new SQLFieldListItem($proto5);

$proto0["m_fieldlist"][]=$obj;
						$proto7=array();
			$obj = new SQLField(array(
	"m_strName" => "TipoDocumento",
	"m_strTable" => "Anamnesis",
	"m_srcTableName" => "Anamnesis"
));

$proto7["m_sql"] = "TipoDocumento";
$proto7["m_srcTableName"] = "Anamnesis";
$proto7["m_expr"]=$obj;
$proto7["m_alias"] = "";
$obj = new SQLFieldListItem($proto7);

$proto0["m_fieldlist"][]=$obj;
						$proto9=array();
			$obj = new SQLField(array(
	"m_strName" => "Numero",
	"m_strTable" => "Anamnesis",
	"m_srcTableName" => "Anamnesis"
));

$proto9["m_sql"] = "Numero";
$proto9["m_srcTableName"] = "Anamnesis";
$proto9["m_expr"]=$obj;
$proto9["m_alias"] = "";
$obj = new SQLFieldListItem($proto9);

$proto0["m_fieldlist"][]=$obj;
						$proto11=array();
			$obj = new SQLField(array(
	"m_strName" => "Fecha",
	"m_strTable" => "Anamnesis",
	"m_srcTableName" => "Anamnesis"
));

$proto11["m_sql"] = "Fecha";
$proto11["m_srcTableName"] = "Anamnesis";
$proto11["m_expr"]=$obj;
$proto11["m_alias"] = "";
$obj = new SQLFieldListItem($proto11);

$proto0["m_fieldlist"][]=$obj;
						$proto13=array();
			$obj = new SQLField(array(
	"m_strName" => "MotivoConsulta",
	"m_strTable" => "Anamnesis",
	"m_srcTableName" => "Anamnesis"
));

$proto13["m_sql"] = "MotivoConsulta";
$proto13["m_srcTableName"] = "Anamnesis";
$proto13["m_expr"]=$obj;
$proto13["m_alias"] = "";
$obj = new SQLFieldListItem($proto13);

$proto0["m_fieldlist"][]=$obj;
						$proto15=array();
			$obj = new SQLField(array(
	"m_strName" => "Anamnesis",
	"m_strTable" => "Anamnesis",
	"m_srcTableName" => "Anamnesis"
));

$proto15["m_sql"] = "Anamnesis";
$proto15["m_srcTableName"] = "Anamnesis";
$proto15["m_expr"]=$obj;
$proto15["m_alias"] = "";
$obj = new SQLFieldListItem($proto15);

$proto0["m_fieldlist"][]=$obj;
						$proto17=array();
			$obj = new SQLField(array(
	"m_strName" => "ExamenFisico",
	"m_strTable" => "Anamnesis",
	"m_srcTableName" => "Anamnesis"
));

$proto17["m_sql"] = "ExamenFisico";
$proto17["m_srcTableName"] = "Anamnesis";
$proto17["m_expr"]=$obj;
$proto17["m_alias"] = "";
$obj = new SQLFieldListItem($proto17);

$proto0["m_fieldlist"][]=$obj;
						$proto19=array();
			$obj = new SQLField(array(
	"m_strName" => "Diagnostico",
	"m_strTable" => "Anamnesis",
	"m_srcTableName" => "Anamnesis"
));

$proto19["m_sql"] = "Diagnostico";
$proto19["m_srcTableName"] = "Anamnesis";
$proto19["m_expr"]=$obj;
$proto19["m_alias"] = "";
$obj = new SQLFieldListItem($proto19);

$proto0["m_fieldlist"][]=$obj;
						$proto21=array();
			$obj = new SQLField(array(
	"m_strName" => "Tratamiento",
	"m_strTable" => "Anamnesis",
	"m_srcTableName" => "Anamnesis"
));

$proto21["m_sql"] = "Tratamiento";
$proto21["m_srcTableName"] = "Anamnesis";
$proto21["m_expr"]=$obj;
$proto21["m_alias"] = "";
$obj = new SQLFieldListItem($proto21);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto23=array();
$proto23["m_link"] = "SQLL_MAIN";
			$proto24=array();
$proto24["m_strName"] = "Anamnesis";
$proto24["m_srcTableName"] = "Anamnesis";
$proto24["m_columns"] = array();
$proto24["m_columns"][] = "IdA";
$proto24["m_columns"][] = "TipoDocumento";
$proto24["m_columns"][] = "Numero";
$proto24["m_columns"][] = "Fecha";
$proto24["m_columns"][] = "MotivoConsulta";
$proto24["m_columns"][] = "Anamnesis";
$proto24["m_columns"][] = "ExamenFisico";
$proto24["m_columns"][] = "Diagnostico";
$proto24["m_columns"][] = "Tratamiento";
$obj = new SQLTable($proto24);

$proto23["m_table"] = $obj;
$proto23["m_sql"] = "Anamnesis";
$proto23["m_alias"] = "";
$proto23["m_srcTableName"] = "Anamnesis";
$proto25=array();
$proto25["m_sql"] = "";
$proto25["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto25["m_column"]=$obj;
$proto25["m_contained"] = array();
$proto25["m_strCase"] = "";
$proto25["m_havingmode"] = false;
$proto25["m_inBrackets"] = false;
$proto25["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto25);

$proto23["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto23);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="Anamnesis";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_Anamnesis = createSqlQuery_Anamnesis();


	
									
	
$tdataAnamnesis[".sqlquery"] = $queryData_Anamnesis;

$tableEvents["Anamnesis"] = new eventsBase;
$tdataAnamnesis[".hasEvents"] = false;

?>